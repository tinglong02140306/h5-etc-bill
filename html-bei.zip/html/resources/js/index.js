// var vConsole;
var requestEvent = {
        // 微信授权登录
        weinxinLogin: function() {
            var curToken = window.location.href.split('token=')[1],
                type = window.location.href.split('type=')[1],
                param;
            if (!curToken) {
                requestEvent.getOauthAddr();
                return;
            }
            param = {
                'token': curToken
            };
            util.ajaxRequest('/wx/login/mp/wechat', param, '', function(res) {
                // util.showToast('用户信息:' + JSON.stringify(res.data))
                if (res.code == "0000") {
                    if (res.data && res.data.auth_token) {
                        util.setLocalToken(res.data.auth_token);
                        handleEvent.pageGopath();
                    }
                } else {
                    util.showToast(res.message)
                }
            }, function(res) {
                util.showToast(res.message)
            });
        },

        // 支付宝授权登录
        alipayLogin: function() {
            var code = window.location.href.split('auth_code=')[1],
                type = window.location.href.split('type=')[1],
                param;
            if (!code) {
                requestEvent.getOauthAddr();
                return;
            }
            param = {
                'auth_code': code
            };
            util.ajaxRequest('/isp/alipay/service/login', param, '', function(res) {
                // util.showToast('用户信息:' + JSON.stringify(res))
                if (res.code == "0000") {
                    if (res.data && res.data.token) {
                        util.setLocalToken(res.data.token);
                        handleEvent.pageGopath(type);
                    }
                } else {
                    util.showToast(res.message)
                }
            }, function(res) {
                util.showToast(res.message)
            });
        },

        // 校验token是否过期
        checkIsValid: function() {
            // util.showToast('checkIsValid');
            util.ajaxRequest('/h5/login/check-token', {}, util.getLocalToken(), function(res) {
                // util.showToast('checkIsValid' + JSON.stringify(res));
                if (res.code == "0000") {
                    // 签约和账单页面跳转
                    handleEvent.pageGopath();
                } else if (res.code == "0007") {
                    // token过期重新授权登录
                    requestEvent.getOauthAddr();
                } else {
                    util.showToast(res.message);
                }
            }, function(res) {
                util.showToast(res.message)
            });
        },
        // 获取授权页面地址
        getOauthAddr: function() {
            var type = 1;
            if (util.isAlipay()) {
                type = 1;
            } else if (util.isWeiXin()) {
                type = 2;
            }
            util.ajaxFormRequest('/isp/alipay/service/oauth-url', { channel: type }, function(res) {
                if (res.code == "0000") {
                    localStorage.removeItem('TOKEN')
                        // util.showToast('getOauthAddr' + res.data);
                    window.location.href = res.data;
                } else {
                    util.showToast(res.message);
                }
            }, function(res) {
                util.showToast(res.message)
            });
        }

    },
    handleEvent = {
        // 页面跳转
        pageGopath: function() {
            var type = window.localStorage.getItem('menuType'),
                path = '';
            // 签约
            if (type == 1) {
                if (util.isAlipay()) {
                    path = './aliSign.html';
                } else if (util.isWeiXin()) {
                    path = './wxSign.html';
                }
                window.location.href = path;
            } else if (type == 2) { // 账单
                path = './bill.html';
                window.location.href = path;
            }

        }
    },
    // 初始化
    init = function() {
        // util.showToast('56789::' + window.location.href);
        // 获取tab类型
        var menuType = (window.location.href.split('menu=')[1]);
        if (menuType) {
            menuType = menuType.split('&')[0];
            window.localStorage.setItem('menuType', menuType);
        }
        if (!!localStorage.getItem('TOKEN')) {
            // 校验token是否过期
            requestEvent.checkIsValid();
        } else if (localStorage.getItem('TOKEN') == null) {
            if (util.isAlipay()) {
                requestEvent.alipayLogin()
            } else if (util.isWeiXin()) {
                requestEvent.weinxinLogin()
            }
        }
    };
$(function() {
    // vConsole = new VConsole();
    init();
});