$(function() {
    util.pushHistory();
    // 监听 左上角返回键和 物理键 关闭页面
    window.addEventListener("popstate", util.dealClosePage, false);
    $('.success-wrap').off('.btn-close').on('click', '.btn-close', function() {
        util.closePage();
    });
})